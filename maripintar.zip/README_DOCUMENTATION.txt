Maripintar Learning Management System

Adit Abdul Azis
Capstone Project Microsoft Indonesia
Bidang Pendidikan

HOW TO INSTALL TO YOUR OWN SERVER

1. Deploy your VM Ubuntu 20.14
2. Install service apache2 phpmyadmin php7.4 mysql-server unzip
3. move to directory, type cd /var/www/html
4. type git clone https://github.com/aditadzacid/maripintar.git
5. unzip maripintar.zip
6. reaccess folder /var/www/html, type chmod 777 /var/www/html
7. move all folder and files in folder maribelajar to /var/www/html
8. return to default access, type chmod 755 /var/www/html
6. Disable Index.html in /var/www/html by renaming files, mv index.html index.html.disable
7. Now edit file, nano /var/www/html/application/config/config.php
8. find $config['base_url'] = 'http://www.maripintar.my.id'; replace www.maripintar.my.id with your ip public/domain
9. edit file again, nano /var/www/html/application/config/database.php
10. find 'username' => 'debian-sys-maint', change with your username phpmyadmin
         'password' => 'CddauW3R4Q6NOelL', change with your password phpmyadmin
11.Open the browser you will got error database, its normal
12.Open in browser your_public_ip/phpmyadmin
13.Create database as name maripintar
14.Import sql file maripintar.sql in db folder /var/www/html/db
15.Done, set as you wish

**LOGIN DETAILS** 

for user create or student

Admin
user: aditazis.id@member.maribelajar.org
pass: admin
